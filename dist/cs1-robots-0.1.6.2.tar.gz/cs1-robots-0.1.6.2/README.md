# Cs1 
This is a cs1 modules that used in ASTU for pip installation

> For installation  

```
pip install cs1-robots
```
### Sample for the robots module usage 

```
from cs1robots import *
create_world()
hubo = Robot()
```

### This code will Result in the following small window

!['./images/sample.png'](./images/sample.png)

## Enjoy Your life with python 3.x all cs1 modules.